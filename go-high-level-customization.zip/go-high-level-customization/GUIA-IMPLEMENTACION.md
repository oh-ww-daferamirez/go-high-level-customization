# 📘 Guía Paso a Paso para Implementar la Personalización en Go High Level

Esta guía te explicará detalladamente cómo implementar la personalización de Go High Level en tu cuenta, sin necesidad de conocimientos técnicos avanzados.

---

## 📋 Contenido

1. [¿Qué es un CDN?](#qué-es-un-cdn)
2. [Opción 1: Usar GitHub Pages (GRATIS)](#opción-1-usar-github-pages-gratis)
3. [Opción 2: Usar Netlify (GRATIS)](#opción-2-usar-netlify-gratis)
4. [Opción 3: Usar tu propio hosting](#opción-3-usar-tu-propio-hosting)
5. [Implementar en Go High Level](#implementar-en-go-high-level)
6. [Verificar que funciona](#verificar-que-funciona)
7. [Solución de problemas](#solución-de-problemas)

---

## 🤔 ¿Qué es un CDN?

**CDN** significa "Content Delivery Network" o "Red de Entrega de Contenidos". 

En términos sencillos:
- Es un servicio que almacena tus archivos (CSS, JS) en servidores alrededor del mundo
- Permite que estos archivos se carguen más rápido en cualquier lugar
- Te da una URL pública para acceder a tus archivos

**Ejemplo:** En lugar de tener tus archivos en tu computadora, los subes a un servicio que te da una URL como: `https://tu-usuario.github.io/archivos/main.css`

---

## 🆓 Opción 1: Usar GitHub Pages (GRATIS)

GitHub Pages es un servicio gratuito de GitHub que te permite alojar archivos estáticos (CSS, JS, HTML) y accederlos vía internet.

### Paso 1: Crear una cuenta en GitHub

1. Ve a [https://github.com](https://github.com)
2. Haz clic en "Sign up" (Registrarse)
3. Completa el formulario de registro
4. Verifica tu email

### Paso 2: Crear un nuevo repositorio

1. Inicia sesión en GitHub
2. Haz clic en el botón **"+"** en la esquina superior derecha
3. Selecciona **"New repository"**
4. Llena los campos:
   - **Repository name**: `ghl-customization` (o el nombre que prefieras)
   - **Description**: `Personalización de Go High Level`
   - Marca la opción **"Public"** (importante)
5. Haz clic en **"Create repository"**

### Paso 3: Subir los archivos

#### Opción A: Subir archivos desde la web (más fácil)

1. En tu repositorio nuevo, haz clic en **"Add file"** → **"Upload files"**
2. Arrastra o selecciona estos archivos desde tu computadora:
   - `css/main.css` (archivo consolidado)
   - `js/main.js` (archivo consolidado)
3. En el campo "Commit changes", escribe: `Subir archivos de personalización`
4. Haz clic en el botón verde **"Commit changes"**

#### Opción B: Usar Git (si sabes usarlo)

```bash
# Clonar el repositorio
git clone https://github.com/TU_USUARIO/ghl-customization.git
cd ghl-customization

# Copiar los archivos
cp /ruta/a/tu/proyecto/css/main.css .
cp /ruta/a/tu/proyecto/js/main.js .

# Subir cambios
git add .
git commit -m "Subir archivos de personalización"
git push origin main
```

### Paso 4: Activar GitHub Pages

1. En tu repositorio, haz clic en la pestaña **"Settings"**
2. En el menú lateral izquierdo, busca **"Pages"**
3. En la sección "Build and deployment" → "Branch":
   - Selecciona **"main"** (o "master")
   - Selecciona **"/ (root)"** en "Folder"
4. Haz clic en **"Save"**

### Paso 5: Obtener las URLs de tus archivos

1. Espera unos minutos (GitHub tarda 1-2 minutos en procesar)
2. Ve a la pestaña **"Code"** en tu repositorio
3. Haz clic en el archivo `main.css`
4. Haz clic en el botón **"Raw"**
5. Copia la URL de la barra de direcciones del navegador

La URL será algo como:
```
https://raw.githubusercontent.com/TU_USUARIO/ghl-customization/main/css/main.css
```

**IMPORTANTE:** Para GitHub Pages, la URL correcta es:
```
https://TU_USUARIO.github.io/ghl-customization/css/main.css
```

Haz lo mismo para `main.js`.

---

## 🚀 Opción 2: Usar Netlify (GRATIS y más rápido)

Netlify es otra opción gratuita que es más fácil de usar y más rápida que GitHub Pages.

### Paso 1: Crear una cuenta en Netlify

1. Ve a [https://app.netlify.com/signup](https://app.netlify.com/signup)
2. Regístrate con tu email o con tu cuenta de GitHub
3. Verifica tu email si es necesario

### Paso 2: Preparar los archivos

Crea una carpeta en tu computadora llamada `ghl-deploy` y coloca allí:
```
ghl-deploy/
├── css/
│   └── main.css
└── js/
    └── main.js
```

### Paso 3: Subir a Netlify

1. Inicia sesión en Netlify
2. En el dashboard, haz clic en **"Add new site"** → **"Deploy manually"**
3. Arrastra la carpeta `ghl-deploy` al área indicada
4. Espera unos segundos mientras Netlify sube los archivos
5. ¡Listo! Netlify te dará una URL aleatoria como:
   ```
   https://amazing-mountain-123456.netlify.app
   ```

### Paso 4: Obtener las URLs

Una vez desplegado, tus archivos estarán disponibles en:
```
https://amazing-mountain-123456.netlify.app/css/main.css
https://amazing-mountain-123456.netlify.app/js/main.js
```

**Bonus:** Puedes cambiar el nombre del sitio en Netlify:
1. Ve a **"Site settings"** → **"Change site name"**
2. Ingresa un nombre como `tu-marca-ghl`
3. La URL será: `https://tu-marca-ghl.netlify.app`

---

## 🌐 Opción 3: Usar tu propio hosting

Si ya tienes un hosting (como Bluehost, HostGator, Namecheap, etc.), puedes usarlo.

### Paso 1: Acceder a tu hosting

1. Inicia sesión en el panel de control de tu hosting (cPanel, Plesk, etc.)
2. Busca el **"Administrador de Archivos"** (File Manager)

### Paso 2: Crear la estructura de carpetas

1. Navega a la carpeta `public_html` o `www`
2. Crea una carpeta llamada `ghl-customization`
3. Dentro, crea las carpetas `css` y `js`

### Paso 3: Subir los archivos

1. En tu computadora, localiza:
   - `css/main.css`
   - `js/main.js`
2. Sube `main.css` a la carpeta `css`
3. Sube `main.js` a la carpeta `js`

### Paso 4: Obtener las URLs

Las URLs serán algo como:
```
https://tu-dominio.com/ghl-customization/css/main.css
https://tu-dominio.com/ghl-customization/js/main.js
```

---

## 🎯 Implementar en Go High Level

Ahora que tienes tus archivos en internet, vamos a implementarlos en Go High Level.

### Paso 1: Iniciar sesión en Go High Level

1. Ve a [https://app.gohighlevel.com](https://app.gohighlevel.com)
2. Inicia sesión con tus credenciales

### Paso 2: Acceder a la configuración del sitio

1. En el menú lateral izquierdo, haz clic en **"Sites"** (Sitios)
2. Selecciona el sitio que quieres personalizar
3. Haz clic en la pestaña **"Tracking"** o **"Custom Code"**

### Paso 3: Agregar el CSS (Head Tracking Code)

1. Busca la sección **"Head Tracking Code"** (Código de seguimiento en el encabezado)
2. En el campo de texto, pega este código:

```html
<!-- Go High Level Customization - CSS -->
<link rel="stylesheet" href="https://TU_URL_AQUI/css/main.css">
```

**IMPORTANTE:** Reemplaza `https://TU_URL_AQUI/css/main.css` con la URL real de tu archivo CSS que obtuviste en los pasos anteriores.

**Ejemplo con GitHub Pages:**
```html
<link rel="stylesheet" href="https://tu-usuario.github.io/ghl-customization/css/main.css">
```

**Ejemplo con Netlify:**
```html
<link rel="stylesheet" href="https://tu-marca-ghl.netlify.app/css/main.css">
```

3. Haz clic en **"Save"** o **"Save Changes"**

### Paso 4: Agregar el JavaScript (Body Tracking Code)

1. Busca la sección **"Body Tracking Code"** (Código de seguimiento en el cuerpo)
2. En el campo de texto, pega este código:

```html
<!-- Go High Level Customization - JavaScript -->
<script src="https://TU_URL_AQUI/js/main.js"></script>
```

**IMPORTANTE:** Reemplaza `https://TU_URL_AQUI/js/main.js` con la URL real de tu archivo JavaScript.

**Ejemplo con GitHub Pages:**
```html
<script src="https://tu-usuario.github.io/ghl-customization/js/main.js"></script>
```

**Ejemplo con Netlify:**
```html
<script src="https://tu-marca-ghl.netlify.app/js/main.js"></script>
```

3. Haz clic en **"Save"** o **"Save Changes"**

### Paso 5: Publicar los cambios

1. Si hay un botón **"Publish"** o **"Deploy"**, haz clic en él
2. Espera unos segundos a que los cambios se apliquen

---

## ✅ Verificar que funciona

### Paso 1: Abrir tu sitio

1. Ve a la URL de tu sitio en Go High Level
2. O abre el editor de páginas y la vista previa

### Paso 2: Verificar los colores

Deberías ver:
- ✅ Los botones con los nuevos colores azules
- ✅ Los formularios con los estilos personalizados
- ✅ Los elementos de la landing page con tu paleta de colores

### Paso 3: Verificar las funcionalidades

1. Haz clic en un botón → Deberías ver una notificación "¡Botón clickeado!"
2. Intenta enviar un formulario → Deberías ver validación en tiempo real
3. Haz scroll en la página → Deberías ver animaciones suaves

### Paso 4: Usar las clases de utilidad

Ahora puedes usar las clases de utilidad en cualquier elemento de Go High Level:

```html
<!-- Botón con color de marca -->
<button class="ghl-btn ghl-btn-primary">Enviar</button>

<!-- Botón con gradiente -->
<button class="ghl-btn ghl-btn-gradient">Comprar Ahora</button>

<!-- Formulario con estilos personalizados -->
<form class="ghl-form">
  <div class="ghl-form-group">
    <label class="ghl-label">Email</label>
    <input type="email" class="ghl-input" placeholder="tu@email.com">
  </div>
  <button type="submit" class="ghl-btn ghl-btn-primary">Enviar</button>
</form>

<!-- Sección con colores de fondo -->
<div class="bg-gradient-primary p-8 text-white">
  <h2>Sección con gradiente</h2>
</div>
```

---

## 🔧 Solución de Problemas

### Problema: Los estilos no se aplican

**Posibles causas:**
1. ❌ La URL del CSS es incorrecta
2. ❌ El archivo CSS no se cargó correctamente
3. ❌ Hay un error de sintaxis en el CSS
4. ❌ El caché del navegador está guardando la versión antigua

**Soluciones:**

1. **Verificar la URL del CSS:**
   - Abre la URL del CSS en una nueva pestaña del navegador
   - Deberías ver el código CSS
   - Si ves "404 Not Found", la URL es incorrecta

2. **Verificar que el archivo se cargó:**
   - En tu sitio, haz clic derecho → "Inspeccionar elemento"
   - Ve a la pestaña "Network" o "Red"
   - Recarga la página
   - Busca `main.css` en la lista
   - Debe mostrar "Status: 200" (éxito)
   - Si muestra "Status: 404", el archivo no existe en esa URL

3. **Limpiar el caché del navegador:**
   - **Chrome/Edge:** Ctrl + Shift + R (Windows) o Cmd + Shift + R (Mac)
   - **Firefox:** Ctrl + F5 (Windows) o Cmd + Shift + R (Mac)
   - **Safari:** Cmd + Option + E (Mac)

4. **Verificar la consola de errores:**
   - Haz clic derecho → "Inspeccionar" → "Console"
   - Busca errores en rojo
   - Si hay errores de sintaxis CSS, corrígelos

### Problema: El JavaScript no funciona

**Posibles causas:**
1. ❌ La URL del JS es incorrecta
2. ❌ El archivo JS se cargó antes que el CSS
3. ❌ Hay un error de sintaxis en el JavaScript
4. ❌ El código JS se está ejecutando antes que el DOM esté listo

**Soluciones:**

1. **Verificar la URL del JS:**
   - Abre la URL del JS en una nueva pestaña
   - Deberías ver el código JavaScript
   - Si ves "404 Not Found", la URL es incorrecta

2. **Verificar el orden de carga:**
   - El CSS debe estar en "Head Tracking Code"
   - El JavaScript debe estar en "Body Tracking Code"
   - Este orden es importante para que los estilos carguen primero

3. **Verificar la consola de errores:**
   - Abre la consola del navegador (F12)
   - Busca errores en rojo
   - Si hay errores de sintaxis JS, corrígelos

4. **Verificar que el script se inicializó:**
   - En la consola, deberías ver:
     ```
     Go High Level Customization initialized successfully!
     ```
   - Si no ves este mensaje, el script no se ejecutó

### Problema: Los colores no se ven correctamente

**Posibles causas:**
1. ❌ Las variables CSS no se están aplicando
2. ❌ Hay estilos de Go High Level que están sobrescribiendo tus estilos
3. ❌ Los colores no tienen suficiente contraste

**Soluciones:**

1. **Verificar las variables CSS:**
   - En la consola, escribe: `getComputedStyle(document.body).getPropertyValue('--color-4')`
   - Deberías ver: `#181a8d`
   - Si ves vacío, las variables no se cargaron

2. **Aumentar la especificidad de tus estilos:**
   - Si Go High Level sobrescribe tus estilos, usa `!important`:
   ```css
   .ghl-btn-primary {
     background-color: var(--primary-color) !important;
   }
   ```

3. **Verificar el contraste:**
   - Usa herramientas como [WebAIM Contrast Checker](https://webaim.org/resources/contrastchecker/)
   - Asegúrate de que el texto sea legible sobre el fondo

### Problema: GitHub Pages no funciona

**Solución:**

1. Verifica que el repositorio sea **PÚBLICO** (no privado)
2. Espera 2-3 minutos después de activar GitHub Pages
3. Verifica que el archivo esté en la rama correcta (main o master)
4. La URL correcta es: `https://TU_USUARIO.github.io/NOMBRE_REPOSITORIO/`

### Problema: Netlify no funciona

**Solución:**

1. Verifica que la estructura de carpetas sea correcta
2. Espera unos segundos después del despliegue
3. Verifica el "Deploys" en Netlify para ver si hubo errores
4. Si hay errores, verifica la consola de Netlify

---

## 📚 Recursos Adicionales

### Documentación de Go High Level
- [Documentación oficial](https://help.gohighlevel.com/)
- [Guía de Custom Code](https://help.gohighlevel.com/support/solutions/articles/48001144906-custom-code)

### Herramientas Útiles
- [GitHub Pages](https://pages.github.com/)
- [Netlify](https://www.netlify.com/)
- [VS Code](https://code.visualstudio.com/) - Editor de código gratuito
- [Chrome DevTools](https://developer.chrome.com/docs/devtools/) - Herramientas de desarrollador

### Aprende Más
- [MDN Web Docs - CSS](https://developer.mozilla.org/en-US/docs/Web/CSS)
- [MDN Web Docs - JavaScript](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
- [W3Schools](https://www.w3schools.com/) - Tutoriales básicos

---

## 🎨 Paleta de Colores Implementada

Tu personalización usa esta paleta de colores azules:

| Color | Hexadecimal | Uso |
|-------|-------------|------|
| Azul Claro | `#4551d8` | Color secundario, acciones destacadas |
| Azul Medio | `#373ebe` | Color de acento, destacar elementos |
| Azul Medio-Oscuro | `#292ca5` | Color informativo, estados |
| Azul Oscuro | `#181a8d` | Color primario de la marca |
| Azul Muy Oscuro | `#000675` | Acento profundo, hover states |

---

## 📞 Soporte

Si tienes problemas después de seguir esta guía:

1. Revisa la sección de **Solución de Problemas** arriba
2. Verifica la consola del navegador para errores
3. Asegúrate de que las URLs sean correctas
4. Limpia el caché del navegador

---

## ✨ ¡Felicidades!

Si has llegado hasta aquí, deberías tener tu personalización de Go High Level funcionando correctamente. 

Ahora puedes:
- ✅ Usar botones personalizados con tus colores de marca
- ✅ Crear formularios con validación en tiempo real
- ✅ Añadir animaciones suaves a tu sitio
- ✅ Usar clases de utilidad para diseño rápido
- ✅ Implementar notificaciones toast y modales

**¡Disfruta tu Go High Level personalizado!** 🎉

---

**Versión:** 1.0.0  
**Última actualización:** 2024  
**Paleta de colores:** Escala de azules profesionales
