/**
 * Animaciones JavaScript para Go High Level
 */

'use strict';

// ========================================
// Intersection Observer para animaciones al scroll
// ========================================
class ScrollAnimations {
  constructor(options = {}) {
    this.options = {
      threshold: options.threshold || 0.1,
      rootMargin: options.rootMargin || '0px 0px -50px 0px',
      animationClass: options.animationClass || 'animate-in',
      hiddenClass: options.hiddenClass || 'animate-hidden'
    };
    
    this.observer = new IntersectionObserver(
      this.handleIntersection.bind(this),
      {
        threshold: this.options.threshold,
        rootMargin: this.options.rootMargin
      }
    );
  }

  handleIntersection(entries) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add(this.options.animationClass);
        entry.target.classList.remove(this.options.hiddenClass);
        this.observer.unobserve(entry.target);
      }
    });
  }

  observe(selector) {
    document.querySelectorAll(selector).forEach(el => {
      el.classList.add(this.options.hiddenClass);
      this.observer.observe(el);
    });
  }

  observeElement(element) {
    element.classList.add(this.options.hiddenClass);
    this.observer.observe(element);
  }

  disconnect() {
    this.observer.disconnect();
  }
}

// ========================================
// Contador animado
// ========================================
class AnimatedCounter {
  constructor(element, options = {}) {
    this.element = element;
    this.options = {
      duration: options.duration || 2000,
      startValue: options.startValue || 0,
      endValue: options.endValue || parseInt(element.textContent.replace(/[^0-9.-]+/g, '')),
      prefix: options.prefix || '',
      suffix: options.suffix || '',
      decimals: options.decimals || 0,
      separator: options.separator || ','
    };
    
    this.startTime = null;
    this.isAnimating = false;
  }

  animate() {
    if (this.isAnimating) return;
    
    this.isAnimating = true;
    this.startTime = null;
    
    requestAnimationFrame(this.update.bind(this));
  }

  update(currentTime) {
    if (!this.startTime) this.startTime = currentTime;
    
    const elapsed = currentTime - this.startTime;
    const progress = Math.min(elapsed / this.options.duration, 1);
    
    // Easing function (easeOutQuart)
    const easeProgress = 1 - Math.pow(1 - progress, 4);
    
    const currentValue = this.options.startValue + 
      (this.options.endValue - this.options.startValue) * easeProgress;
    
    this.element.textContent = this.formatValue(currentValue);
    
    if (progress < 1) {
      requestAnimationFrame(this.update.bind(this));
    } else {
      this.isAnimating = false;
    }
  }

  formatValue(value) {
    const formatted = value.toFixed(this.options.decimals);
    const parts = formatted.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, this.options.separator);
    return this.options.prefix + parts.join('.') + this.options.suffix;
  }
}

// ========================================
// Contador regresivo
// ========================================
class CountdownTimer {
  constructor(element, endDate, options = {}) {
    this.element = element;
    this.endDate = new Date(endDate).getTime();
    this.options = {
      onTick: options.onTick || null,
      onComplete: options.onComplete || null,
      format: options.format || 'd:h:m:s'
    };
    
    this.interval = null;
  }

  start() {
    this.update();
    this.interval = setInterval(() => this.update(), 1000);
  }

  update() {
    const now = new Date().getTime();
    const distance = this.endDate - now;

    if (distance < 0) {
      this.stop();
      if (this.options.onComplete) {
        this.options.onComplete();
      }
      return;
    }

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    const formatted = this.formatTime(days, hours, minutes, seconds);
    this.element.innerHTML = formatted;

    if (this.options.onTick) {
      this.options.onTick({ days, hours, minutes, seconds });
    }
  }

  formatTime(days, hours, minutes, seconds) {
    const format = this.options.format;
    let result = '';

    if (format.includes('d')) {
      result += `<span class="countdown-value">${days}</span><span class="countdown-label">d</span> `;
    }
    if (format.includes('h')) {
      result += `<span class="countdown-value">${hours}</span><span class="countdown-label">h</span> `;
    }
    if (format.includes('m')) {
      result += `<span class="countdown-value">${minutes}</span><span class="countdown-label">m</span> `;
    }
    if (format.includes('s')) {
      result += `<span class="countdown-value">${seconds}</span><span class="countdown-label">s</span>`;
    }

    return result;
  }

  stop() {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
    }
  }
}

// ========================================
// Typewriter effect
// ========================================
class Typewriter {
  constructor(element, options = {}) {
    this.element = element;
    this.options = {
      text: options.text || element.textContent,
      speed: options.speed || 50,
      delay: options.delay || 1000,
      cursor: options.cursor !== false,
      cursorChar: options.cursorChar || '|',
      loop: options.loop || false,
      deleteSpeed: options.deleteSpeed || 30
    };
    
    this.element.textContent = '';
    this.currentIndex = 0;
    this.isDeleting = false;
    this.timeout = null;
  }

  start() {
    this.type();
  }

  type() {
    const currentText = this.options.text;
    
    if (this.isDeleting) {
      this.element.textContent = currentText.substring(0, this.currentIndex - 1);
      this.currentIndex--;
    } else {
      this.element.textContent = currentText.substring(0, this.currentIndex + 1);
      this.currentIndex++;
    }

    let typeSpeed = this.options.speed;

    if (this.isDeleting) {
      typeSpeed = this.options.deleteSpeed;
    }

    if (!this.isDeleting && this.currentIndex === currentText.length) {
      typeSpeed = this.options.delay;
      this.isDeleting = true;
    } else if (this.isDeleting && this.currentIndex === 0) {
      if (this.options.loop) {
        this.isDeleting = false;
      } else {
        return;
      }
    }

    this.timeout = setTimeout(() => this.type(), typeSpeed);
  }

  stop() {
    if (this.timeout) {
      clearTimeout(this.timeout);
      this.timeout = null;
    }
  }
}

// ========================================
// Parallax effect
// ========================================
class Parallax {
  constructor(element, options = {}) {
    this.element = element;
    this.options = {
      speed: options.speed || 0.5,
      direction: options.direction || 'vertical',
      offset: options.offset || 0
    };
    
    this.init();
  }

  init() {
    window.addEventListener('scroll', this.handleScroll.bind(this));
  }

  handleScroll() {
    const scrollY = window.pageYOffset;
    const offset = scrollY * this.options.speed + this.options.offset;

    if (this.options.direction === 'vertical') {
      this.element.style.transform = `translateY(${offset}px)`;
    } else if (this.options.direction === 'horizontal') {
      this.element.style.transform = `translateX(${offset}px)`;
    }
  }

  destroy() {
    window.removeEventListener('scroll', this.handleScroll.bind(this));
  }
}

// ========================================
// Fade in on scroll
// ========================================
class FadeInScroll {
  constructor(selector, options = {}) {
    this.selector = selector;
    this.options = {
      threshold: options.threshold || 0.1,
      rootMargin: options.rootMargin || '0px',
      duration: options.duration || 600
    };
    
    this.observer = new IntersectionObserver(
      this.handleIntersection.bind(this),
      {
        threshold: this.options.threshold,
        rootMargin: this.options.rootMargin
      }
    );
    
    this.init();
  }

  init() {
    document.querySelectorAll(this.selector).forEach(el => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(20px)';
      el.style.transition = `opacity ${this.options.duration}ms ease, transform ${this.options.duration}ms ease`;
      this.observer.observe(el);
    });
  }

  handleIntersection(entries) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        this.observer.unobserve(entry.target);
      }
    });
  }

  destroy() {
    this.observer.disconnect();
  }
}

// ========================================
// Initialize animations
// ========================================
function initAnimations() {
  // Scroll animations
  const scrollAnimations = new ScrollAnimations();
  scrollAnimations.observe('.ghl-animate-on-scroll');

  // Animated counters
  document.querySelectorAll('.ghl-animated-counter').forEach(el => {
    const counter = new AnimatedCounter(el);
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          counter.animate();
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });
    observer.observe(el);
  });

  // Countdown timers
  document.querySelectorAll('.ghl-countdown').forEach(el => {
    const endDate = el.dataset.endDate;
    if (endDate) {
      const countdown = new CountdownTimer(el, endDate);
      countdown.start();
    }
  });

  // Typewriter effect
  document.querySelectorAll('.ghl-typewriter').forEach(el => {
    const typewriter = new Typewriter(el);
    typewriter.start();
  });

  // Fade in on scroll
  const fadeInScroll = new FadeInScroll('.ghl-fade-in');
}

// ========================================
// Export animations
// ========================================
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    ScrollAnimations,
    AnimatedCounter,
    CountdownTimer,
    Typewriter,
    Parallax,
    FadeInScroll,
    initAnimations
  };
}

// Initialize on DOM ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initAnimations);
} else {
  initAnimations();
}
