/**
 * Script principal para Go High Level
 * Inicializa todos los componentes y funcionalidades
 */

'use strict';

// ========================================
// Configuración global
// ========================================
const GHLConfig = {
  version: '1.0.0',
  colors: {
    primary: '#181a8d',
    secondary: '#4551d8',
    accent1: '#373ebe',
    accent2: '#292ca5',
    accent3: '#000675'
  },
  breakpoints: {
    mobile: 640,
    tablet: 768,
    desktop: 1024,
    wide: 1280
  }
};

// ========================================
// Estado global de la aplicación
// ========================================
const GHLState = {
  isMobile: false,
  isTablet: false,
  isDesktop: false,
  scrollY: 0,
  scrollDirection: 'down',
  lastScrollY: 0
};

// ========================================
// Detectar dispositivo
// ========================================
function detectDevice() {
  const width = window.innerWidth;
  GHLState.isMobile = width < GHLConfig.breakpoints.tablet;
  GHLState.isTablet = width >= GHLConfig.breakpoints.tablet && width < GHLConfig.breakpoints.desktop;
  GHLState.isDesktop = width >= GHLConfig.breakpoints.desktop;
  
  document.body.classList.toggle('is-mobile', GHLState.isMobile);
  document.body.classList.toggle('is-tablet', GHLState.isTablet);
  document.body.classList.toggle('is-desktop', GHLState.isDesktop);
}

// ========================================
// Manejar scroll
// ========================================
function handleScroll() {
  const currentScrollY = window.pageYOffset;
  GHLState.scrollDirection = currentScrollY > GHLState.lastScrollY ? 'down' : 'up';
  GHLState.scrollY = currentScrollY;
  GHLState.lastScrollY = currentScrollY;
  
  document.body.classList.toggle('scrolled', currentScrollY > 50);
  document.body.classList.toggle('scrolling-down', GHLState.scrollDirection === 'down');
  document.body.classList.toggle('scrolling-up', GHLState.scrollDirection === 'up');
}

// ========================================
// Smooth scroll para enlaces internos
// ========================================
function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const href = this.getAttribute('href');
      if (href === '#') return;
      
      e.preventDefault();
      const target = document.querySelector(href);
      if (target) {
        const offset = 80; // Ajustar según el header
        const elementPosition = target.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - offset;
        
        window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
        });
      }
    });
  });
}

// ========================================
// Lazy loading de imágenes
// ========================================
function initLazyLoading() {
  if ('loading' in HTMLImageElement.prototype) {
    // Navegador soporta lazy loading nativo
    document.querySelectorAll('img[data-src]').forEach(img => {
      img.src = img.dataset.src;
      img.removeAttribute('data-src');
    });
  } else {
    // Fallback para navegadores antiguos
    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
          img.removeAttribute('data-src');
          observer.unobserve(img);
        }
      });
    });
    
    document.querySelectorAll('img[data-src]').forEach(img => {
      imageObserver.observe(img);
    });
  }
}

// ========================================
// Header sticky con efecto
// ========================================
function initStickyHeader() {
  const header = document.querySelector('.ghl-header');
  if (!header) return;
  
  let lastScroll = 0;
  const scrollThreshold = 100;
  
  window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > scrollThreshold) {
      header.classList.add('ghl-header-sticky');
    } else {
      header.classList.remove('ghl-header-sticky');
    }
    
    if (currentScroll > lastScroll && currentScroll > scrollThreshold) {
      header.classList.add('ghl-header-hidden');
    } else {
      header.classList.remove('ghl-header-hidden');
    }
    
    lastScroll = currentScroll;
  });
}

// ========================================
// Mobile menu toggle
// ========================================
function initMobileMenu() {
  const toggleButton = document.querySelector('.ghl-mobile-menu-toggle');
  const mobileMenu = document.querySelector('.ghl-mobile-menu');
  
  if (!toggleButton || !mobileMenu) return;
  
  toggleButton.addEventListener('click', () => {
    const isOpen = mobileMenu.classList.contains('open');
    mobileMenu.classList.toggle('open');
    toggleButton.classList.toggle('active');
    document.body.classList.toggle('menu-open', !isOpen);
  });
  
  // Cerrar menú al hacer clic en un enlace
  mobileMenu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      mobileMenu.classList.remove('open');
      toggleButton.classList.remove('active');
      document.body.classList.remove('menu-open');
    });
  });
  
  // Cerrar menú al hacer clic fuera
  document.addEventListener('click', (e) => {
    if (!mobileMenu.contains(e.target) && !toggleButton.contains(e.target)) {
      mobileMenu.classList.remove('open');
      toggleButton.classList.remove('active');
      document.body.classList.remove('menu-open');
    }
  });
}

// ========================================
// Toast notifications
// ========================================
class Toast {
  constructor(message, options = {}) {
    this.message = message;
    this.options = {
      type: options.type || 'success', // success, error, warning, info
      duration: options.duration || 3000,
      position: options.position || 'top-right', // top-right, top-left, bottom-right, bottom-left
      showClose: options.showClose !== false
    };
    
    this.element = null;
    this.timeout = null;
  }

  show() {
    this.element = document.createElement('div');
    this.element.className = `ghl-toast ghl-toast-${this.options.type}`;
    this.element.innerHTML = `
      <div class="ghl-toast-content">
        <span class="ghl-toast-message">${this.message}</span>
        ${this.options.showClose ? '<button class="ghl-toast-close">&times;</button>' : ''}
      </div>
    `;
    
    // Add styles
    this.element.style.cssText = `
      position: fixed;
      z-index: 9999;
      padding: 1rem 1.5rem;
      border-radius: 0.5rem;
      box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
      display: flex;
      align-items: center;
      gap: 0.75rem;
      animation: slideIn 0.3s ease;
      max-width: 400px;
      ${this.getPositionStyles()}
    `;
    
    // Set color based on type
    const colors = {
      success: 'background: #10b981; color: white;',
      error: 'background: #ef4444; color: white;',
      warning: 'background: #f59e0b; color: white;',
      info: 'background: #373ebe; color: white;'
    };
    this.element.style.cssText += colors[this.options.type];
    
    document.body.appendChild(this.element);
    
    // Add close button event
    const closeBtn = this.element.querySelector('.ghl-toast-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.hide());
    }
    
    // Auto hide
    if (this.options.duration > 0) {
      this.timeout = setTimeout(() => this.hide(), this.options.duration);
    }
  }

  getPositionStyles() {
    const positions = {
      'top-right': 'top: 1rem; right: 1rem;',
      'top-left': 'top: 1rem; left: 1rem;',
      'bottom-right': 'bottom: 1rem; right: 1rem;',
      'bottom-left': 'bottom: 1rem; left: 1rem;'
    };
    return positions[this.options.position];
  }

  hide() {
    if (this.timeout) {
      clearTimeout(this.timeout);
    }
    
    this.element.style.animation = 'slideOut 0.3s ease';
    setTimeout(() => {
      if (this.element && this.element.parentNode) {
        this.element.parentNode.removeChild(this.element);
      }
    }, 300);
  }
}

// ========================================
// Modal
// ========================================
class Modal {
  constructor(element, options = {}) {
    this.element = element;
    this.options = {
      closeOnOverlay: options.closeOnOverlay !== false,
      closeOnEscape: options.closeOnEscape !== false,
      onOpen: options.onOpen || null,
      onClose: options.onClose || null
    };
    
    this.overlay = null;
    this.isOpen = false;
    this.init();
  }

  init() {
    // Create overlay
    this.overlay = document.createElement('div');
    this.overlay.className = 'ghl-modal-overlay';
    this.overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.5);
      display: none;
      justify-content: center;
      align-items: center;
      z-index: 9998;
      animation: fadeIn 0.3s ease;
    `;
    
    // Style modal
    this.element.style.cssText += `
      position: fixed;
      z-index: 9999;
      display: none;
      animation: scaleIn 0.3s ease;
    `;
    
    // Find close buttons
    const closeButtons = this.element.querySelectorAll('[data-modal-close]');
    closeButtons.forEach(btn => {
      btn.addEventListener('click', () => this.close());
    });
    
    // Close on overlay click
    if (this.options.closeOnOverlay) {
      this.overlay.addEventListener('click', () => this.close());
    }
    
    // Close on escape
    if (this.options.closeOnEscape) {
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && this.isOpen) {
          this.close();
        }
      });
    }
  }

  open() {
    document.body.appendChild(this.overlay);
    this.overlay.style.display = 'flex';
    this.element.style.display = 'block';
    document.body.style.overflow = 'hidden';
    this.isOpen = true;
    
    if (this.options.onOpen) {
      this.options.onOpen();
    }
  }

  close() {
    this.overlay.style.display = 'none';
    this.element.style.display = 'none';
    document.body.style.overflow = '';
    this.isOpen = false;
    
    if (this.options.onClose) {
      this.options.onClose();
    }
  }

  destroy() {
    this.close();
    if (this.overlay && this.overlay.parentNode) {
      this.overlay.parentNode.removeChild(this.overlay);
    }
  }
}

// ========================================
// Accordion
// ========================================
function initAccordions() {
  document.querySelectorAll('.ghl-accordion').forEach(accordion => {
    const items = accordion.querySelectorAll('.ghl-accordion-item');
    
    items.forEach(item => {
      const header = item.querySelector('.ghl-accordion-header');
      const content = item.querySelector('.ghl-accordion-content');
      
      header.addEventListener('click', () => {
        const isOpen = item.classList.contains('open');
        
        // Close all items
        items.forEach(i => {
          i.classList.remove('open');
          i.querySelector('.ghl-accordion-content').style.maxHeight = '0';
        });
        
        // Open clicked item if it was closed
        if (!isOpen) {
          item.classList.add('open');
          content.style.maxHeight = content.scrollHeight + 'px';
        }
      });
    });
  });
}

// ========================================
// Tabs
// ========================================
function initTabs() {
  document.querySelectorAll('.ghl-tabs').forEach(tabContainer => {
    const tabButtons = tabContainer.querySelectorAll('.ghl-tab-button');
    const tabContents = tabContainer.querySelectorAll('.ghl-tab-content');
    
    tabButtons.forEach((button, index) => {
      button.addEventListener('click', () => {
        // Remove active class from all buttons and contents
        tabButtons.forEach(btn => btn.classList.remove('active'));
        tabContents.forEach(content => content.classList.remove('active'));
        
        // Add active class to clicked button and corresponding content
        button.classList.add('active');
        tabContents[index].classList.add('active');
      });
    });
  });
}

// ========================================
// Initialize all components
// ========================================
function initAll() {
  // Detect device
  detectDevice();
  window.addEventListener('resize', debounce(detectDevice, 250));
  
  // Handle scroll
  window.addEventListener('scroll', throttle(handleScroll, 100));
  
  // Initialize components
  initSmoothScroll();
  initLazyLoading();
  initStickyHeader();
  initMobileMenu();
  initAccordions();
  initTabs();
  
  // Initialize animations if available
  if (typeof initAnimations === 'function') {
    initAnimations();
  }
  
  // Initialize form components if available
  if (typeof initFormComponents === 'function') {
    initFormComponents();
  }
  
  console.log('Go High Level Customization initialized successfully!');
}

// ========================================
// Global functions
// ========================================
window.GHL = {
  config: GHLConfig,
  state: GHLState,
  Toast,
  Modal,
  init: initAll
};

// ========================================
// Initialize on DOM ready
// ========================================
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initAll);
} else {
  initAll();
}

// ========================================
// Add animation keyframes
// ========================================
const style = document.createElement('style');
style.textContent = `
  @keyframes slideIn {
    from {
      transform: translateX(100%);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
  
  @keyframes slideOut {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(100%);
      opacity: 0;
    }
  }
  
  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  
  @keyframes scaleIn {
    from {
      transform: scale(0.9);
      opacity: 0;
    }
    to {
      transform: scale(1);
      opacity: 1;
    }
  }
`;
document.head.appendChild(style);
