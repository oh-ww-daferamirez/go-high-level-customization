/**
 * Utilidades JavaScript para Go High Level
 */

'use strict';

// ========================================
// Debounce function
// ========================================
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// ========================================
// Throttle function
// ========================================
function throttle(func, limit) {
  let inThrottle;
  return function(...args) {
    if (!inThrottle) {
      func.apply(this, args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
}

// ========================================
// Check if element is in viewport
// ========================================
function isInViewport(element) {
  const rect = element.getBoundingClientRect();
  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
}

// ========================================
// Smooth scroll to element
// ========================================
function scrollToElement(element, offset = 0) {
  if (!element) return;
  
  const elementPosition = element.getBoundingClientRect().top;
  const offsetPosition = elementPosition + window.pageYOffset - offset;

  window.scrollTo({
    top: offsetPosition,
    behavior: 'smooth'
  });
}

// ========================================
// Format currency
// ========================================
function formatCurrency(amount, currency = 'USD', locale = 'en-US') {
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency: currency
  }).format(amount);
}

// ========================================
// Format number with commas
// ========================================
function formatNumber(number) {
  return new Intl.NumberFormat('en-US').format(number);
}

// ========================================
// Format date
// ========================================
function formatDate(date, options = {}) {
  const defaultOptions = {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  };
  return new Intl.DateTimeFormat('en-US', { ...defaultOptions, ...options }).format(date);
}

// ========================================
// Format time
// ========================================
function formatTime(date, options = {}) {
  const defaultOptions = {
    hour: '2-digit',
    minute: '2-digit'
  };
  return new Intl.DateTimeFormat('en-US', { ...defaultOptions, ...options }).format(date);
}

// ========================================
// Generate random ID
// ========================================
function generateId(prefix = 'id') {
  return `${prefix}-${Math.random().toString(36).substr(2, 9)}`;
}

// ========================================
// Deep clone object
// ========================================
function deepClone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

// ========================================
// Check if device is mobile
// ========================================
function isMobile() {
  return window.innerWidth <= 768;
}

// ========================================
// Check if device is tablet
// ========================================
function isTablet() {
  return window.innerWidth > 768 && window.innerWidth <= 1024;
}

// ========================================
// Check if device is desktop
// ========================================
function isDesktop() {
  return window.innerWidth > 1024;
}

// ========================================
// Get query parameter from URL
// ========================================
function getQueryParam(param) {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get(param);
}

// ========================================
// Set query parameter in URL
// ========================================
function setQueryParam(param, value) {
  const url = new URL(window.location);
  url.searchParams.set(param, value);
  window.history.pushState({}, '', url);
}

// ========================================
// Remove query parameter from URL
// ========================================
function removeQueryParam(param) {
  const url = new URL(window.location);
  url.searchParams.delete(param);
  window.history.pushState({}, '', url);
}

// ========================================
// Copy text to clipboard
// ========================================
async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (err) {
    console.error('Failed to copy text: ', err);
    return false;
  }
}

// ========================================
// Download file
// ========================================
function downloadFile(content, filename, type = 'text/plain') {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// ========================================
// Validate email
// ========================================
function isValidEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

// ========================================
// Validate phone number
// ========================================
function isValidPhone(phone) {
  const re = /^[\+]?[(]?[0-9]{3}[)]?[-\s.]?[0-9]{3}[-\s.]?[0-9]{4,6}$/;
  return re.test(phone);
}

// ========================================
// Validate URL
// ========================================
function isValidUrl(url) {
  try {
    new URL(url);
    return true;
  } catch (err) {
    return false;
  }
}

// ========================================
// Sanitize HTML
// ========================================
function sanitizeHtml(html) {
  const div = document.createElement('div');
  div.textContent = html;
  return div.innerHTML;
}

// ========================================
// Escape HTML
// ========================================
function escapeHtml(unsafe) {
  return unsafe
    .replace(/&/g, '&')
    .replace(/</g, '<')
    .replace(/>/g, '>')
    .replace(/"/g, '"')
    .replace(/'/g, '&#039;');
}

// ========================================
// Local storage helpers
// ========================================
const storage = {
  set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (err) {
      console.error('Error saving to localStorage:', err);
      return false;
    }
  },
  
  get(key, defaultValue = null) {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch (err) {
      console.error('Error reading from localStorage:', err);
      return defaultValue;
    }
  },
  
  remove(key) {
    try {
      localStorage.removeItem(key);
      return true;
    } catch (err) {
      console.error('Error removing from localStorage:', err);
      return false;
    }
  },
  
  clear() {
    try {
      localStorage.clear();
      return true;
    } catch (err) {
      console.error('Error clearing localStorage:', err);
      return false;
    }
  }
};

// ========================================
// Session storage helpers
// ========================================
const sessionStorage = {
  set(key, value) {
    try {
      window.sessionStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (err) {
      console.error('Error saving to sessionStorage:', err);
      return false;
    }
  },
  
  get(key, defaultValue = null) {
    try {
      const item = window.sessionStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch (err) {
      console.error('Error reading from sessionStorage:', err);
      return defaultValue;
    }
  },
  
  remove(key) {
    try {
      window.sessionStorage.removeItem(key);
      return true;
    } catch (err) {
      console.error('Error removing from sessionStorage:', err);
      return false;
    }
  },
  
  clear() {
    try {
      window.sessionStorage.clear();
      return true;
    } catch (err) {
      console.error('Error clearing sessionStorage:', err);
      return false;
    }
  }
};

// ========================================
// Cookie helpers
// ========================================
const cookies = {
  set(name, value, days = 7) {
    const date = new Date();
    date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
    const expires = `expires=${date.toUTCString()}`;
    document.cookie = `${name}=${value};${expires};path=/`;
  },
  
  get(name) {
    const nameEQ = `${name}=`;
    const ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) === ' ') c = c.substring(1, c.length);
      if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
  },
  
  remove(name) {
    document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/`;
  }
};

// ========================================
// Event delegation
// ========================================
function delegate(parent, selector, event, handler) {
  parent.addEventListener(event, function(e) {
    const target = e.target.closest(selector);
    if (target && parent.contains(target)) {
      handler.call(target, e);
    }
  });
}

// ========================================
// Wait for element
// ========================================
function waitForElement(selector, callback, timeout = 10000) {
  const startTime = Date.now();
  
  const check = () => {
    const element = document.querySelector(selector);
    if (element) {
      callback(element);
      return;
    }
    
    if (Date.now() - startTime >= timeout) {
      console.warn(`Element ${selector} not found within ${timeout}ms`);
      return;
    }
    
    requestAnimationFrame(check);
  };
  
  check();
}

// ========================================
// Load external script
// ========================================
function loadScript(src, callback) {
  const script = document.createElement('script');
  script.src = src;
  script.async = true;
  script.onload = callback;
  script.onerror = () => console.error(`Failed to load script: ${src}`);
  document.head.appendChild(script);
}

// ========================================
// Load external stylesheet
// ========================================
function loadStylesheet(href, callback) {
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = href;
  link.onload = callback;
  link.onerror = () => console.error(`Failed to load stylesheet: ${href}`);
  document.head.appendChild(link);
}

// ========================================
// Export utilities
// ========================================
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    debounce,
    throttle,
    isInViewport,
    scrollToElement,
    formatCurrency,
    formatNumber,
    formatDate,
    formatTime,
    generateId,
    deepClone,
    isMobile,
    isTablet,
    isDesktop,
    getQueryParam,
    setQueryParam,
    removeQueryParam,
    copyToClipboard,
    downloadFile,
    isValidEmail,
    isValidPhone,
    isValidUrl,
    sanitizeHtml,
    escapeHtml,
    storage,
    sessionStorage,
    cookies,
    delegate,
    waitForElement,
    loadScript,
    loadStylesheet
  };
}
