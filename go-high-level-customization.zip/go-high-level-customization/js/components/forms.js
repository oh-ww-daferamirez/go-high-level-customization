/**
 * Componentes de formularios JavaScript para Go High Level
 */

'use strict';

// ========================================
// Validador de formularios
// ========================================
class FormValidator {
  constructor(formElement, options = {}) {
    this.form = formElement;
    this.rules = options.rules || {};
    this.options = {
      errorClass: options.errorClass || 'error',
      successClass: options.successClass || 'success',
      errorElement: options.errorElement || 'ghl-form-error-message',
      onValidate: options.onValidate || null,
      onSubmit: options.onSubmit || null
    };
    
    this.init();
  }

  init() {
    this.form.addEventListener('submit', (e) => this.handleSubmit(e));
    
    this.form.querySelectorAll('input, select, textarea').forEach(field => {
      field.addEventListener('blur', () => this.validateField(field));
      field.addEventListener('input', () => this.clearError(field));
    });
  }

  addRule(fieldName, rule) {
    this.rules[fieldName] = rule;
  }

  validateField(field) {
    const rule = this.rules[field.name];
    if (!rule) return true;

    let isValid = true;
    let errorMessage = '';

    if (rule.required && !field.value.trim()) {
      isValid = false;
      errorMessage = rule.requiredMessage || 'Este campo es requerido';
    } else if (rule.email && !this.isValidEmail(field.value)) {
      isValid = false;
      errorMessage = rule.emailMessage || 'Por favor ingresa un email válido';
    } else if (rule.minLength && field.value.length < rule.minLength) {
      isValid = false;
      errorMessage = rule.minLengthMessage || `Mínimo ${rule.minLength} caracteres`;
    } else if (rule.maxLength && field.value.length > rule.maxLength) {
      isValid = false;
      errorMessage = rule.maxLengthMessage || `Máximo ${rule.maxLength} caracteres`;
    } else if (rule.pattern && !rule.pattern.test(field.value)) {
      isValid = false;
      errorMessage = rule.patternMessage || 'Formato inválido';
    } else if (rule.match && field.value !== document.querySelector(rule.match).value) {
      isValid = false;
      errorMessage = rule.matchMessage || 'Los campos no coinciden';
    } else if (rule.custom && !rule.custom(field.value)) {
      isValid = false;
      errorMessage = rule.customMessage || 'Valor inválido';
    }

    this.updateFieldStatus(field, isValid, errorMessage);
    
    if (this.options.onValidate) {
      this.options.onValidate(field, isValid, errorMessage);
    }
    
    return isValid;
  }

  isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  updateFieldStatus(field, isValid, errorMessage) {
    const formGroup = field.closest('.ghl-form-group');
    const errorElement = formGroup.querySelector(`.${this.options.errorElement}`);
    
    if (isValid) {
      field.classList.remove(this.options.errorClass);
      field.classList.add(this.options.successClass);
      formGroup.classList.remove('has-error');
      formGroup.classList.add('has-success');
      if (errorElement) errorElement.remove();
    } else {
      field.classList.remove(this.options.successClass);
      field.classList.add(this.options.errorClass);
      formGroup.classList.remove('has-success');
      formGroup.classList.add('has-error');
      
      if (!errorElement) {
        const newErrorElement = document.createElement('div');
        newErrorElement.className = this.options.errorElement;
        formGroup.appendChild(newErrorElement);
      }
      formGroup.querySelector(`.${this.options.errorElement}`).textContent = errorMessage;
    }
  }

  clearError(field) {
    const formGroup = field.closest('.ghl-form-group');
    field.classList.remove(this.options.errorClass);
    formGroup.classList.remove('has-error');
    const errorElement = formGroup.querySelector(`.${this.options.errorElement}`);
    if (errorElement) errorElement.remove();
  }

  handleSubmit(e) {
    e.preventDefault();
    let isFormValid = true;

    this.form.querySelectorAll('input, select, textarea').forEach(field => {
      if (!this.validateField(field)) {
        isFormValid = false;
      }
    });

    if (isFormValid) {
      if (this.options.onSubmit) {
        this.options.onSubmit(this.form);
      } else {
        this.form.submit();
      }
    }
  }

  reset() {
    this.form.reset();
    this.form.querySelectorAll('.error, .success').forEach(el => {
      el.classList.remove('error', 'success');
    });
    this.form.querySelectorAll('.has-error, .has-success').forEach(el => {
      el.classList.remove('has-error', 'has-success');
    });
    this.form.querySelectorAll(`.${this.options.errorElement}`).forEach(el => {
      el.remove();
    });
  }
}

// ========================================
// Auto-resize para textareas
// ========================================
function initAutoResizeTextareas() {
  document.querySelectorAll('textarea[data-auto-resize]').forEach(textarea => {
    const resize = () => {
      textarea.style.height = 'auto';
      textarea.style.height = textarea.scrollHeight + 'px';
    };
    
    textarea.addEventListener('input', resize);
    resize();
  });
}

// ========================================
// Máscara para números de teléfono
// ========================================
function initPhoneMasks() {
  document.querySelectorAll('input[data-phone-mask]').forEach(input => {
    input.addEventListener('input', function(e) {
      let value = this.value.replace(/\D/g, '');
      if (value.length > 10) value = value.slice(0, 10);
      
      let formatted = '';
      if (value.length > 0) formatted = `(${value.slice(0, 3)}`;
      if (value.length > 3) formatted += `) ${value.slice(3, 6)}`;
      if (value.length > 6) formatted += `-${value.slice(6)}`;
      
      this.value = formatted;
    });
  });
}

// ========================================
// Máscara para fechas
// ========================================
function initDateMasks() {
  document.querySelectorAll('input[data-date-mask]').forEach(input => {
    input.addEventListener('input', function(e) {
      let value = this.value.replace(/\D/g, '');
      if (value.length > 8) value = value.slice(0, 8);
      
      let formatted = '';
      if (value.length > 0) formatted = value.slice(0, 2);
      if (value.length > 2) formatted += `/${value.slice(2, 4)}`;
      if (value.length > 4) formatted += `/${value.slice(4)}`;
      
      this.value = formatted;
    });
  });
}

// ========================================
// Toggle password visibility
// ========================================
function initPasswordToggles() {
  document.querySelectorAll('.ghl-password-toggle').forEach(button => {
    const input = button.previousElementSibling;
    
    button.addEventListener('click', function() {
      const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
      input.setAttribute('type', type);
      
      // Update icon
      const icon = this.querySelector('svg');
      if (icon) {
        icon.innerHTML = type === 'password' 
          ? '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />'
          : '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />';
      }
    });
  });
}

// ========================================
// Character counter
// ========================================
function initCharacterCounters() {
  document.querySelectorAll('textarea[data-char-count]').forEach(textarea => {
    const maxLength = textarea.getAttribute('maxlength');
    const counter = document.createElement('div');
    counter.className = 'ghl-char-counter';
    counter.style.fontSize = '0.75rem';
    counter.style.color = 'var(--text-tertiary)';
    counter.style.textAlign = 'right';
    counter.style.marginTop = '0.25rem';
    textarea.parentNode.appendChild(counter);

    const updateCounter = () => {
      const currentLength = textarea.value.length;
      counter.textContent = `${currentLength}/${maxLength}`;
      
      if (currentLength >= maxLength * 0.9) {
        counter.style.color = 'var(--warning-color)';
      }
      if (currentLength >= maxLength) {
        counter.style.color = 'var(--error-color)';
      }
    };

    textarea.addEventListener('input', updateCounter);
    updateCounter();
  });
}

// ========================================
// Form stepper
// ========================================
class FormStepper {
  constructor(formElement, options = {}) {
    this.form = formElement;
    this.options = {
      stepClass: options.stepClass || 'ghl-step',
      activeClass: options.activeClass || 'active',
      completedClass: options.completedClass || 'completed',
      nextButton: options.nextButton || '.ghl-next-step',
      prevButton: options.prevButton || '.ghl-prev-step',
      submitButton: options.submitButton || '.ghl-submit-form',
      onStepChange: options.onStepChange || null,
      onComplete: options.onComplete || null
    };
    
    this.steps = Array.from(this.form.querySelectorAll(this.options.stepClass));
    this.currentStep = 0;
    this.init();
  }

  init() {
    this.showStep(0);
    
    this.form.querySelectorAll(this.options.nextButton).forEach(btn => {
      btn.addEventListener('click', () => this.nextStep());
    });
    
    this.form.querySelectorAll(this.options.prevButton).forEach(btn => {
      btn.addEventListener('click', () => this.prevStep());
    });
  }

  showStep(index) {
    this.steps.forEach((step, i) => {
      step.style.display = i === index ? 'block' : 'none';
      step.classList.remove(this.options.activeClass);
      
      if (i < index) {
        step.classList.add(this.options.completedClass);
      } else {
        step.classList.remove(this.options.completedClass);
      }
    });
    
    this.steps[index].classList.add(this.options.activeClass);
    this.currentStep = index;
    
    // Update buttons
    const prevButtons = this.form.querySelectorAll(this.options.prevButton);
    const nextButtons = this.form.querySelectorAll(this.options.nextButton);
    const submitButtons = this.form.querySelectorAll(this.options.submitButton);
    
    prevButtons.forEach(btn => {
      btn.style.display = index === 0 ? 'none' : 'inline-block';
    });
    
    nextButtons.forEach(btn => {
      btn.style.display = index === this.steps.length - 1 ? 'none' : 'inline-block';
    });
    
    submitButtons.forEach(btn => {
      btn.style.display = index === this.steps.length - 1 ? 'inline-block' : 'none';
    });
    
    if (this.options.onStepChange) {
      this.options.onStepChange(index);
    }
  }

  nextStep() {
    if (this.currentStep < this.steps.length - 1) {
      this.showStep(this.currentStep + 1);
    }
  }

  prevStep() {
    if (this.currentStep > 0) {
      this.showStep(this.currentStep - 1);
    }
  }

  goToStep(index) {
    if (index >= 0 && index < this.steps.length) {
      this.showStep(index);
    }
  }
}

// ========================================
// Initialize form components
// ========================================
function initFormComponents() {
  // Auto-resize textareas
  initAutoResizeTextareas();
  
  // Phone masks
  initPhoneMasks();
  
  // Date masks
  initDateMasks();
  
  // Password toggles
  initPasswordToggles();
  
  // Character counters
  initCharacterCounters();
}

// ========================================
// Export form components
// ========================================
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    FormValidator,
    FormStepper,
    initFormComponents,
    initAutoResizeTextareas,
    initPhoneMasks,
    initDateMasks,
    initPasswordToggles,
    initCharacterCounters
  };
}

// Initialize on DOM ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initFormComponents);
} else {
  initFormComponents();
}
